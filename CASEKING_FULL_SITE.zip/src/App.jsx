// אתר CASEKING עם Coins, קופסאות לפי ערך, ומערכת Wallet בסיסית

import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const cases = [
  {
    id: 1,
    name: "Sniper Case",
    image: "https://example.com/sniper-case.png",
    price: 5, // Coins
    items: [
      { name: "AWP | Dragon Lore", rarity: "epic", value: 1500, image: "https://example.com/dragon-lore.png" },
      { name: "AWP | Asiimov", rarity: "rare", value: 60, image: "https://example.com/awp-asiimov.png" },
      { name: "SSG 08 | Ghost", rarity: "common", value: 1.2, image: "https://example.com/ssg08-ghost.png" },
    ],
  },
  {
    id: 2,
    name: "Pistol Case",
    image: "https://example.com/pistol-case.png",
    price: 2,
    items: [
      { name: "Glock-18 | Fade", rarity: "epic", value: 200, image: "https://example.com/glock-fade.png" },
      { name: "USP-S | Guardian", rarity: "rare", value: 20, image: "https://example.com/usp-guardian.png" },
      { name: "P250 | Sand Dune", rarity: "common", value: 0.5, image: "https://example.com/p250.png" },
    ],
  },
];

const getRandomItem = (items) => {
  const weights = items.map((item) =>
    item.rarity === "epic" ? 1 : item.rarity === "rare" ? 5 : 20
  );
  const sum = weights.reduce((a, b) => a + b, 0);
  let rand = Math.random() * sum;
  for (let i = 0; i < items.length; i++) {
    if (rand < weights[i]) return items[i];
    rand -= weights[i];
  }
  return items[0];
};

export default function CaseKing() {
  const [coins, setCoins] = useState(1000000); // התחלה עם מיליון Coins
  const [openedItem, setOpenedItem] = useState(null);
  const [isOpening, setIsOpening] = useState(false);

  const openCase = (csCase) => {
    if (coins < csCase.price) return alert("אין לך מספיק Coins!");
    setIsOpening(true);
    setCoins((prev) => prev - csCase.price);
    setTimeout(() => {
      const item = getRandomItem(csCase.items);
      setOpenedItem(item);
      setIsOpening(false);
    }, 2000);
  };

  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold mb-4">🎁 CASEKING - פתח קופסה וזכה בפרסים</h1>

      <div className="mb-6 text-lg font-semibold text-green-600">
        💰 הארנק שלך: {coins.toFixed(2)} Coins
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center justify-center">
        {cases.map((csCase) => (
          <Card key={csCase.id} className="p-4">
            <CardContent>
              <img src={csCase.image} alt={csCase.name} className="mx-auto mb-2 w-32 h-32 object-contain" />
              <h2 className="text-xl font-semibold">{csCase.name}</h2>
              <p className="text-sm text-gray-600">מחיר: {csCase.price} Coins</p>
              <Button onClick={() => openCase(csCase)} disabled={isOpening || coins < csCase.price} className="mt-4">
                {isOpening ? "פותח..." : "פתח קופסה"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {openedItem && !isOpening && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="mt-8 p-6 bg-gray-900 text-white rounded-xl inline-block shadow-xl"
        >
          <h2 className="text-xl font-bold mb-2">🎉 זכית ב:</h2>
          <img src={openedItem.image} alt={openedItem.name} className="w-24 h-24 mx-auto mb-2" />
          <p className="text-lg">{openedItem.name}</p>
          <p className="text-sm text-yellow-400">שווי: {openedItem.value} $</p>
        </motion.div>
      )}
    </div>
  );
}
